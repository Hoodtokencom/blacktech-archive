#!/usr/bin/env python3
"""
South Side Business Network — Server with Real Posting
Port: 8099
"""
import http.server, socketserver, os, json, sqlite3, urllib.parse, threading, time, uuid, cgi, glob
from datetime import datetime, timedelta

UPLOAD_DIR = '/home/allenai/ssbn_uploads'
os.makedirs(UPLOAD_DIR, exist_ok=True)

PORT = 8099
HTML_FILE = '/home/allenai/southside_network.html'
DB_FILE   = '/home/allenai/data/ssbn.db'

# ── Init DB ──────────────────────────────────────────────────────────────────
def init_db():
    con = sqlite3.connect(DB_FILE)
    con.execute('''CREATE TABLE IF NOT EXISTS comments (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        post_id   INTEGER NOT NULL,
        name      TEXT DEFAULT 'Community Member',
        message   TEXT NOT NULL,
        created_at TEXT NOT NULL
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS posts (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        biz_name  TEXT NOT NULL,
        biz_type  TEXT DEFAULT 'Community Member',
        post_type TEXT DEFAULT '📣 General Update',
        message   TEXT NOT NULL,
        tags      TEXT DEFAULT '',
        likes     INTEGER DEFAULT 0,
        created_at TEXT NOT NULL
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS members (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        name      TEXT NOT NULL,
        phone     TEXT,
        biz_type  TEXT,
        zip_code  TEXT DEFAULT '60628',
        created_at TEXT NOT NULL
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS events (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        title       TEXT NOT NULL,
        description TEXT DEFAULT '',
        location    TEXT DEFAULT '',
        event_date  TEXT NOT NULL,
        host_name   TEXT DEFAULT 'Community Member',
        rsvp_count  INTEGER DEFAULT 0,
        created_at  TEXT NOT NULL
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS hood_tokens (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        member_name TEXT NOT NULL,
        action      TEXT NOT NULL,
        tokens      INTEGER DEFAULT 1,
        created_at  TEXT NOT NULL
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS push_subs (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        sub_json  TEXT NOT NULL,
        created_at TEXT NOT NULL
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS donations (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        donor_name  TEXT DEFAULT 'Anonymous',
        amount      REAL NOT NULL,
        month       INTEGER DEFAULT 0,
        note        TEXT DEFAULT '',
        created_at  TEXT NOT NULL
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS files (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        filename    TEXT NOT NULL,
        orig_name   TEXT NOT NULL,
        uploader    TEXT DEFAULT 'Community Member',
        category    TEXT DEFAULT 'General',
        description TEXT DEFAULT '',
        file_size   INTEGER DEFAULT 0,
        created_at  TEXT NOT NULL
    )''')
    # Add image_url column if missing
    try:
        con.execute('ALTER TABLE posts ADD COLUMN image_url TEXT DEFAULT ""')
        con.commit()
    except: pass
    # Add file_url and file_name columns if missing
    try:
        con.execute('ALTER TABLE posts ADD COLUMN file_url TEXT DEFAULT ""')
        con.commit()
    except: pass
    try:
        con.execute('ALTER TABLE posts ADD COLUMN file_name TEXT DEFAULT ""')
        con.commit()
    except: pass
    # Seed with existing static posts if empty
    if con.execute('SELECT COUNT(*) FROM posts').fetchone()[0] == 0:
        seed = [
            ('Blacktech Solutions Corp', 'Electrical Contractor', '📣 General Update',
             'We help you navigate the application — no fee, no gimmicks. Over 200 South Side homes served. 🏡💚',
             'EnergyEquity,Roseland', 24),
            ('Queen\'s Catering', 'Food & Catering', '🎉 Announcement',
             'Now booking for summer events! Weddings, graduations, block parties. South Side owned & operated. 🍽️',
             'Catering,Events,60620', 18),
            ('Think Energy Chicago', 'Energy Advisor', '💼 Job / Opportunity',
             'Hiring Energy Advisors in the 60628 area. No experience needed — we train you. Earn while you learn!',
             'Jobs,Energy,Hiring', 31),
            ('King\'s Barbershop', 'Barber / Beauty', '🏷️ Special Offer / Promo',
             'Back to school cuts starting at $15! Walk-ins welcome. 79th & Halsted. 💈',
             'Barbershop,BackToSchool,79thStreet', 42),
        ]
        for biz_name, biz_type, post_type, message, tags, likes in seed:
            con.execute(
                'INSERT INTO posts (biz_name,biz_type,post_type,message,tags,likes,created_at) VALUES (?,?,?,?,?,?,?)',
                (biz_name, biz_type, post_type, message, tags, likes,
                 datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
            )
    con.commit()
    con.close()

def get_posts():
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    rows = con.execute('SELECT * FROM posts ORDER BY id DESC LIMIT 50').fetchall()
    posts = [dict(r) for r in rows]
    # Add comment count to each post
    for p in posts:
        count = con.execute('SELECT COUNT(*) FROM comments WHERE post_id=?', (p['id'],)).fetchone()[0]
        p['comment_count'] = count
    con.close()
    return posts

def save_post(data):
    con = sqlite3.connect(DB_FILE)
    con.execute(
        'INSERT INTO posts (biz_name,biz_type,post_type,message,tags,likes,image_url,file_url,file_name,created_at) VALUES (?,?,?,?,?,0,?,?,?,?)',
        (data.get('biz_name','Community Member'),
         data.get('biz_type','Community Member'),
         data.get('post_type','📣 General Update'),
         data.get('message',''),
         data.get('tags',''),
         data.get('image_url',''),
         data.get('file_url',''),
         data.get('file_name',''),
         datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    )
    con.commit()
    con.close()

def like_post(post_id):
    con = sqlite3.connect(DB_FILE)
    con.execute('UPDATE posts SET likes = likes + 1 WHERE id = ?', (post_id,))
    row = con.execute('SELECT likes FROM posts WHERE id = ?', (post_id,)).fetchone()
    con.commit()
    con.close()
    return row[0] if row else 0

def get_comments(post_id):
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    rows = con.execute('SELECT * FROM comments WHERE post_id=? ORDER BY id ASC', (post_id,)).fetchall()
    con.close()
    return [dict(r) for r in rows]

def save_comment(post_id, name, message):
    con = sqlite3.connect(DB_FILE)
    con.execute('INSERT INTO comments (post_id,name,message,created_at) VALUES (?,?,?,?)',
        (post_id, name, message, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    con.execute('UPDATE posts SET likes=likes WHERE id=?', (post_id,))  # touch row
    con.commit()
    con.close()

def get_members():
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    rows = con.execute('SELECT * FROM members ORDER BY id ASC').fetchall()
    con.close()
    return [dict(r) for r in rows]

# ── Events ───────────────────────────────────────────────────────────────────
def get_events():
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    rows = con.execute('SELECT * FROM events ORDER BY event_date ASC').fetchall()
    con.close()
    return [dict(r) for r in rows]

def save_event(data):
    con = sqlite3.connect(DB_FILE)
    con.execute(
        'INSERT INTO events (title,description,location,event_date,host_name,rsvp_count,created_at) VALUES (?,?,?,?,?,0,?)',
        (data.get('title',''), data.get('description',''),
         data.get('location',''), data.get('event_date',''),
         data.get('host_name','Community Member'),
         datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    )
    con.commit()
    con.close()

def rsvp_event(event_id):
    con = sqlite3.connect(DB_FILE)
    con.execute('UPDATE events SET rsvp_count = rsvp_count + 1 WHERE id = ?', (event_id,))
    row = con.execute('SELECT rsvp_count FROM events WHERE id = ?', (event_id,)).fetchone()
    con.commit()
    con.close()
    return row[0] if row else 0

# ── HOOD Token Rewards ────────────────────────────────────────────────────────
HOOD_REWARDS = {'post': 5, 'comment': 2, 'like': 1, 'rsvp': 3, 'signup': 10}

def award_hood(member_name, action):
    tokens = HOOD_REWARDS.get(action, 1)
    con = sqlite3.connect(DB_FILE)
    con.execute('INSERT INTO hood_tokens (member_name,action,tokens,created_at) VALUES (?,?,?,?)',
        (member_name, action, tokens, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    con.commit()
    total = con.execute('SELECT SUM(tokens) FROM hood_tokens WHERE member_name=?', (member_name,)).fetchone()[0] or 0
    con.close()
    return {'earned': tokens, 'total': total}

def get_hood_balance(member_name):
    con = sqlite3.connect(DB_FILE)
    total = con.execute('SELECT SUM(tokens) FROM hood_tokens WHERE member_name=?', (member_name,)).fetchone()[0] or 0
    con.close()
    return total

def get_hood_leaderboard():
    con = sqlite3.connect(DB_FILE)
    rows = con.execute('SELECT member_name, SUM(tokens) as total FROM hood_tokens GROUP BY member_name ORDER BY total DESC LIMIT 10').fetchall()
    con.close()
    return [{'name': r[0], 'tokens': r[1]} for r in rows]

def save_member(data):
    con = sqlite3.connect(DB_FILE)
    # ensure neighborhood column exists
    try:
        con.execute('ALTER TABLE members ADD COLUMN neighborhood TEXT DEFAULT "Roseland"')
        con.commit()
    except: pass
    con.execute(
        'INSERT INTO members (name,phone,biz_type,zip_code,neighborhood,created_at) VALUES (?,?,?,?,?,?)',
        (data.get('name',''), data.get('phone',''),
         data.get('biz_type',''), data.get('zip_code','60628'),
         data.get('neighborhood',''), datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    )
    con.commit()
    con.close()

# ── HTTP Handler ─────────────────────────────────────────────────────────────
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): pass

    def _json(self, data, status=200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        path = self.path.split('?')[0]

        if path == '/api/posts':
            self._json({'ok': True, 'posts': get_posts()})

        elif path == '/api/members':
            self._json({'ok': True, 'members': get_members()})

        elif path.startswith('/api/member-detail'):
            mid = self.path.split('?id=')[-1] if '?id=' in self.path else '0'
            con = sqlite3.connect(DB_FILE)
            con.row_factory = sqlite3.Row
            row = con.execute('SELECT * FROM members WHERE id=?', (int(mid),)).fetchone()
            con.close()
            if row:
                self._json({'ok': True, 'member': dict(row)})
            else:
                self._json({'ok': False, 'error': 'not found'}, 404)

        elif path.startswith('/api/comments'):
            post_id = int(self.path.split('?post_id=')[-1]) if '?post_id=' in self.path else 0
            self._json({'ok': True, 'comments': get_comments(post_id)})

        elif path == '/api/events':
            self._json({'ok': True, 'events': get_events()})

        elif path == '/api/hood-leaderboard':
            self._json({'ok': True, 'leaderboard': get_hood_leaderboard()})

        elif path.startswith('/api/hood-balance'):
            name = urllib.parse.unquote(self.path.split('?name=')[-1]) if '?name=' in self.path else ''
            self._json({'ok': True, 'tokens': get_hood_balance(name)})

        elif path == '/api/donations':
            con = sqlite3.connect(DB_FILE)
            rows = con.execute('SELECT id, donor_name, amount, month, note, created_at FROM donations ORDER BY created_at DESC').fetchall()
            con.close()
            donations = [{'id': r[0], 'donor_name': r[1], 'amount': r[2], 'month': r[3], 'note': r[4], 'created_at': r[5]} for r in rows]
            total = sum(d['amount'] for d in donations)
            self._json({'ok': True, 'donations': donations, 'total': total})

        elif path == '/api/files':
            con = sqlite3.connect(DB_FILE)
            con.row_factory = sqlite3.Row
            rows = con.execute('SELECT * FROM files ORDER BY created_at DESC').fetchall()
            con.close()
            files = [dict(r) for r in rows]
            self._json({'ok': True, 'files': files})

        elif path == '/api/health':
            self._json({'ok': True, 'service': 'SSBN'})

        elif path.startswith('/uploads/'):
            # Serve uploaded images
            filename = path.split('/uploads/')[-1]
            filepath = os.path.join(UPLOAD_DIR, filename)
            if os.path.isfile(filepath) and not '..' in filename:
                ext = filename.rsplit('.', 1)[-1].lower()
                ct = {'jpg':'image/jpeg','jpeg':'image/jpeg','png':'image/png','gif':'image/gif','webp':'image/webp',
                      'pdf':'application/pdf','doc':'application/msword','docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                      'xls':'application/vnd.ms-excel','xlsx':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                      'csv':'text/csv','txt':'text/plain','mp4':'video/mp4','zip':'application/zip'}.get(ext, 'application/octet-stream')
                self.send_response(200)
                self.send_header('Content-Type', ct)
                self.send_header('Cache-Control', 'public, max-age=3600')
                self.end_headers()
                with open(filepath, 'rb') as f:
                    self.wfile.write(f.read())
            else:
                self.send_response(404)
                self.end_headers()

        else:
            try:
                with open(HTML_FILE, 'rb') as f:
                    content = f.read()
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
                self.send_header('Pragma', 'no-cache')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.end_headers()
                self.wfile.write(content)
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(str(e).encode())

    def do_POST(self):
        length = int(self.headers.get('Content-Length', 0))
        content_type = self.headers.get('Content-Type', '')
        path = self.path.split('?')[0]

        # ── Photo upload (multipart) ──
        if path == '/api/upload-photo':
            try:
                if 'multipart/form-data' not in content_type:
                    self._json({'ok': False, 'error': 'multipart required'}, 400)
                    return
                # Parse multipart
                boundary = content_type.split('boundary=')[-1].encode()
                body = self.rfile.read(length)
                # Find file data between boundaries
                parts = body.split(b'--' + boundary)
                image_data = None
                orig_ext = 'jpg'
                for part in parts:
                    if b'filename=' in part:
                        # Get filename
                        header_end = part.find(b'\r\n\r\n')
                        if header_end == -1: continue
                        header_section = part[:header_end].decode('utf-8', errors='ignore')
                        file_data = part[header_end + 4:]
                        # Trim trailing \r\n
                        if file_data.endswith(b'\r\n'):
                            file_data = file_data[:-2]
                        if not file_data: continue
                        # Get extension from filename
                        import re
                        fn_match = re.search(r'filename="?([^"\r\n]+)"?', header_section)
                        if fn_match:
                            fname = fn_match.group(1)
                            if '.' in fname:
                                orig_ext = fname.rsplit('.', 1)[-1].lower()
                        image_data = file_data
                        break

                if not image_data or len(image_data) < 100:
                    self._json({'ok': False, 'error': 'no valid image found'}, 400)
                    return

                # Validate size (5MB max)
                if len(image_data) > 5 * 1024 * 1024:
                    self._json({'ok': False, 'error': 'image too large (5MB max)'}, 400)
                    return

                # Validate extension
                allowed = {'jpg', 'jpeg', 'png', 'gif', 'webp'}
                if orig_ext not in allowed:
                    orig_ext = 'jpg'

                # Save with unique name
                filename = f"{uuid.uuid4().hex[:12]}.{orig_ext}"
                filepath = os.path.join(UPLOAD_DIR, filename)
                with open(filepath, 'wb') as f:
                    f.write(image_data)

                image_url = f"/uploads/{filename}"
                self._json({'ok': True, 'image_url': image_url, 'filename': filename})
            except Exception as e:
                self._json({'ok': False, 'error': str(e)}, 500)
            return

        body = self.rfile.read(length)
        try:
            data = json.loads(body)
        except Exception:
            self._json({'ok': False, 'error': 'bad json'}, 400)
            return

        path = self.path.split('?')[0]

        if path == '/api/post':
            if not data.get('message','').strip():
                self._json({'ok': False, 'error': 'message required'}, 400)
                return
            save_post(data)
            self._json({'ok': True, 'message': 'Post saved!'})

        elif path == '/api/like':
            likes = like_post(data.get('id', 0))
            hood = award_hood(data.get('name','Community Member'), 'like')
            self._json({'ok': True, 'likes': likes, 'hood': hood})

        elif path == '/api/comment':
            post_id = data.get('post_id', 0)
            name    = data.get('name', 'Community Member')
            message = data.get('message', '').strip()
            if not message:
                self._json({'ok': False, 'error': 'message required'}, 400)
                return
            save_comment(post_id, name, message)
            hood = award_hood(name, 'comment')
            self._json({'ok': True, 'comments': get_comments(post_id), 'hood': hood})

        elif path == '/api/edit-post':
            post_id = data.get('id', 0)
            message = data.get('message', '').strip()
            post_type = data.get('post_type', '').strip()
            if not message:
                self._json({'ok': False, 'error': 'message required'}, 400)
                return
            con = sqlite3.connect(DB_FILE)
            fields = ['message=?']
            vals = [message]
            if post_type:
                fields.append('post_type=?')
                vals.append(post_type)
            vals.append(post_id)
            con.execute(f"UPDATE posts SET {','.join(fields)} WHERE id=?", vals)
            con.commit()
            con.close()
            self._json({'ok': True, 'message': 'Post updated!'})

        elif path == '/api/delete-post':
            post_id = data.get('id', 0)
            con = sqlite3.connect(DB_FILE)
            con.execute('DELETE FROM posts WHERE id = ?', (post_id,))
            con.commit()
            con.close()
            self._json({'ok': True})

        elif path == '/api/delete-member':
            mid = data.get('id', 0)
            con = sqlite3.connect(DB_FILE)
            con.execute('DELETE FROM members WHERE id = ?', (mid,))
            con.commit()
            con.close()
            self._json({'ok': True})

        elif path == '/api/event':
            if not data.get('title','').strip():
                self._json({'ok': False, 'error': 'title required'}, 400)
                return
            save_event(data)
            hood = award_hood(data.get('host_name','Community Member'), 'post')
            self._json({'ok': True, 'message': 'Event created!', 'hood': hood})

        elif path == '/api/rsvp':
            event_id = data.get('id', 0)
            count = rsvp_event(event_id)
            hood = award_hood(data.get('name','Community Member'), 'rsvp')
            self._json({'ok': True, 'rsvp_count': count, 'hood': hood})

        elif path == '/api/post':
            if not data.get('message','').strip():
                self._json({'ok': False, 'error': 'message required'}, 400)
                return
            save_post(data)
            hood = award_hood(data.get('biz_name','Community Member'), 'post')
            self._json({'ok': True, 'message': 'Post saved!', 'hood': hood})

        elif path == '/api/member':
            if not data.get('name','').strip():
                self._json({'ok': False, 'error': 'name required'}, 400)
                return
            save_member(data)
            self._json({'ok': True, 'message': 'Member registered!'})

        elif path == '/api/member-update':
            mid = data.get('id')
            if not mid:
                self._json({'ok': False, 'error': 'id required'}, 400)
                return
            con = sqlite3.connect(DB_FILE)
            fields = []
            vals = []
            for f in ['name','phone','biz_type','zip_code','neighborhood','email','address','website','description']:
                if f in data:
                    fields.append(f'{f}=?')
                    vals.append(data[f])
            if not fields:
                self._json({'ok': False, 'error': 'no fields to update'}, 400)
                return
            vals.append(int(mid))
            con.execute(f"UPDATE members SET {','.join(fields)} WHERE id=?", vals)
            con.commit()
            con.close()
            self._json({'ok': True, 'message': 'Profile updated!'})

        elif path == '/api/donation':
            amount = data.get('amount', 0)
            try:
                amount = float(amount)
            except (ValueError, TypeError):
                self._json({'ok': False, 'error': 'invalid amount'}, 400)
                return
            if amount <= 0:
                self._json({'ok': False, 'error': 'amount must be positive'}, 400)
                return
            donor_name = data.get('donor_name', 'Anonymous').strip() or 'Anonymous'
            note = data.get('note', '').strip()
            month = int(data.get('month', 0))
            con = sqlite3.connect(DB_FILE)
            con.execute('INSERT INTO donations (donor_name, amount, month, note, created_at) VALUES (?,?,?,?,?)',
                        (donor_name, amount, month, note, datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')))
            con.commit()
            con.close()
            hood = award_hood(donor_name, 'post')
            self._json({'ok': True, 'message': 'Donation recorded! 💚', 'hood': hood})

        elif path == '/api/upload-file':
            try:
                if 'multipart/form-data' not in content_type:
                    self._json({'ok': False, 'error': 'multipart required'}, 400)
                    return
                boundary = content_type.split('boundary=')[-1].encode()
                body = self.rfile.read(length)
                parts = body.split(b'--' + boundary)
                file_data = None
                orig_name = 'file'
                uploader = 'Community Member'
                category = 'General'
                description = ''
                for part in parts:
                    if b'filename=' in part:
                        header_end = part.find(b'\r\n\r\n')
                        if header_end == -1: continue
                        header_section = part[:header_end].decode('utf-8', errors='ignore')
                        fdata = part[header_end + 4:]
                        if fdata.endswith(b'\r\n'):
                            fdata = fdata[:-2]
                        if not fdata: continue
                        import re as _re
                        fn_match = _re.search(r'filename="?([^"\r\n]+)"?', header_section)
                        if fn_match:
                            orig_name = fn_match.group(1)
                        file_data = fdata
                    elif b'name="uploader"' in part:
                        val = part.split(b'\r\n\r\n', 1)[-1].strip().rstrip(b'\r\n--')
                        uploader = val.decode('utf-8', errors='ignore').strip() or 'Community Member'
                    elif b'name="category"' in part:
                        val = part.split(b'\r\n\r\n', 1)[-1].strip().rstrip(b'\r\n--')
                        category = val.decode('utf-8', errors='ignore').strip() or 'General'
                    elif b'name="description"' in part:
                        val = part.split(b'\r\n\r\n', 1)[-1].strip().rstrip(b'\r\n--')
                        description = val.decode('utf-8', errors='ignore').strip()

                if not file_data or len(file_data) < 10:
                    self._json({'ok': False, 'error': 'no valid file found'}, 400)
                    return
                # 20MB max
                if len(file_data) > 20 * 1024 * 1024:
                    self._json({'ok': False, 'error': 'file too large (20MB max)'}, 400)
                    return
                # Allowed extensions
                ext = orig_name.rsplit('.', 1)[-1].lower() if '.' in orig_name else 'bin'
                allowed = {'pdf','doc','docx','xls','xlsx','csv','txt','png','jpg','jpeg','gif','webp','mp4','zip'}
                if ext not in allowed:
                    self._json({'ok': False, 'error': f'file type .{ext} not allowed'}, 400)
                    return
                # Save file
                import uuid as _uuid
                safe_name = f"{_uuid.uuid4().hex[:12]}.{ext}"
                os.makedirs(UPLOAD_DIR, exist_ok=True)
                filepath = os.path.join(UPLOAD_DIR, safe_name)
                with open(filepath, 'wb') as wf:
                    wf.write(file_data)
                # Save to DB
                con = sqlite3.connect(DB_FILE)
                con.execute('INSERT INTO files (filename, orig_name, uploader, category, description, file_size, created_at) VALUES (?,?,?,?,?,?,?)',
                            (safe_name, orig_name, uploader, category, description, len(file_data),
                             datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')))
                con.commit()
                con.close()
                self._json({'ok': True, 'message': 'File uploaded! 📁', 'url': f'/uploads/{safe_name}'})
            except Exception as e:
                self._json({'ok': False, 'error': str(e)}, 500)

        elif path == '/api/delete-file':
            fid = data.get('id')
            if not fid:
                self._json({'ok': False, 'error': 'id required'}, 400)
                return
            con = sqlite3.connect(DB_FILE)
            row = con.execute('SELECT filename FROM files WHERE id=?', (int(fid),)).fetchone()
            if row:
                fpath = os.path.join(UPLOAD_DIR, row[0])
                if os.path.isfile(fpath):
                    os.remove(fpath)
                con.execute('DELETE FROM files WHERE id=?', (int(fid),))
                con.commit()
            con.close()
            self._json({'ok': True, 'message': 'File deleted'})

        else:
            self._json({'ok': False, 'error': 'not found'}, 404)

if __name__ == '__main__':
    init_db()

    # ── Auto-delete comments older than 24 hours + expired photos ────────────
    def cleanup_old_content():
        while True:
            time.sleep(3600)  # run every hour
            try:
                cutoff = (datetime.utcnow() - timedelta(hours=24)).strftime('%Y-%m-%d %H:%M:%S')
                con = sqlite3.connect(DB_FILE)
                # Delete old comments
                deleted_comments = con.execute('DELETE FROM comments WHERE created_at < ?', (cutoff,)).rowcount
                # Delete photos from posts older than 24h
                expired_posts = con.execute('SELECT image_url FROM posts WHERE image_url != "" AND created_at < ?', (cutoff,)).fetchall()
                for row in expired_posts:
                    img_url = row[0]
                    if img_url.startswith('/uploads/'):
                        fpath = os.path.join(UPLOAD_DIR, img_url.split('/uploads/')[-1])
                        if os.path.isfile(fpath):
                            os.remove(fpath)
                # Clear image_url from expired posts (photo gone, text stays)
                con.execute('UPDATE posts SET image_url="" WHERE image_url != "" AND created_at < ?', (cutoff,))
                con.commit()
                deleted_photos = len(expired_posts)
                con.close()
                if deleted_comments or deleted_photos:
                    print(f'[cleanup] Deleted {deleted_comments} comment(s), {deleted_photos} photo(s) older than 24h')
            except Exception as e:
                print(f'[cleanup] Error: {e}')

    t = threading.Thread(target=cleanup_old_content, daemon=True)
    t.start()

    class ReuseServer(socketserver.TCPServer):
        allow_reuse_address = True
    with ReuseServer(('0.0.0.0', PORT), Handler) as httpd:
        print(f'South Side Business Network running on port {PORT}')
        httpd.serve_forever()
